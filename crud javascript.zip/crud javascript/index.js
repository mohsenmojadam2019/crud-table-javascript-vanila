let id = "no";
// localStorage.clear();
selectData();
//sudo do-release-upgrade -d

function manageData  ()  {

    let name=document.getElementById('name').value;
    if (name == '') {
        document.getElementById('msg').innerHTML = "Please enter name";

    } else {
        if (id == "no") {
            let arr = getCrudData();
            if (arr == null) {
                let data = [name];
                setCrudData(data);
            } else {
                arr.push(name);
                setCrudData(arr);
            }
            document.getElementById("msg").innerHTML = "Data added successfully";

        } else {
            let arr = getCrudData();
            arr[id] = name;
            setCrudData(arr);
            document.getElementById("name").value = "";
            document.getElementById("msg").innerHTML = "Data updated successfully";
            id = "";
        }
        selectData();
    }
}
function selectData  () {
    let arr = JSON.parse(localStorage.getItem("crud"));
    if (arr != null) {
        let html = "";
        let sno = 1;
        for (let k in arr) {
           html=html+
               `<tr>
        <td>${sno}</td>
        <td>${arr[k]}</td>
        <td>
        <a href="javascript:void(0)" onclick="EditData(${k})">Edit</a>
        &nbsp;
        <a href="javascript:void(0)" onclick="deleteData(${k})">Delete</a>
        </td>
        </tr>`
            sno++;
        }
        document.getElementById("root").innerHTML = html;
    }
}
function getCrudData  ()  {
    return JSON.parse(localStorage.getItem("crud"));
}

function EditData  (rid) {
    let arr = getCrudData();
    id = rid;
    document.getElementById("name").value = arr[rid];
}

function deleteData  (rid)  {
    let arr = getCrudData();
    arr.splice(rid, 1);
    setCrudData(arr);
    selectData();
}

function setCrudData (arr) {
    localStorage.setItem("crud", JSON.stringify(arr));
}





